import java.util.Scanner;

public class LinearSearch2D {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Rows & Cols: ");
        int r = sc.nextInt(), c = sc.nextInt();
        int[][] a = new int[r][c];

        System.out.println("Enter matrix:");
        for (int i = 0; i < r; i++)
            for (int j = 0; j < c; j++)
                a[i][j] = sc.nextInt();

        System.out.print("Enter element to search: ");
        int x = sc.nextInt();

        boolean found = false;
        for (int i = 0; i < r; i++) {
            for (int j = 0; j < c; j++) {
                if (a[i][j] == x) {
                    System.out.println("Found at position: (" + i + ", " + j + ")");
                    found = true;
                }
            }
        }
        if (!found) System.out.println("Not found");
    }
}
