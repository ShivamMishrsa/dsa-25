import java.util.Scanner;
import java.util.Arrays;

public class ArrayInsertDelete {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n;
        System.out.print("Enter initial array size: ");
        n = sc.nextInt();
        int[] arr = new int[Math.max(10, n + 5)]; // capacity
        System.out.println("Enter elements:");
        for (int i = 0; i < n; i++) arr[i] = sc.nextInt();
        int size = n;

        while (true) {
            System.out.println("\n1.Insert 2.Delete 3.Display 4.Exit");
            int ch = sc.nextInt();
            if (ch == 1) {
                System.out.print("Enter element and position (0-based): ");
                int x = sc.nextInt(), pos = sc.nextInt();
                if (pos < 0 || pos > size) {
                    System.out.println("Invalid position");
                    continue;
                }
                // shift right
                for (int i = size; i > pos; i--) arr[i] = arr[i - 1];
                arr[pos] = x;
                size++;
                System.out.println("Inserted.");
            } else if (ch == 2) {
                System.out.print("Enter position to delete (0-based): ");
                int pos = sc.nextInt();
                if (pos < 0 || pos >= size) {
                    System.out.println("Invalid position");
                    continue;
                }
                // shift left
                for (int i = pos; i < size - 1; i++) arr[i] = arr[i + 1];
                size--;
                System.out.println("Deleted.");
            } else if (ch == 3) {
                System.out.println("Array: " + Arrays.toString(Arrays.copyOf(arr, size)));
            } else break;
        }
        sc.close();
    }
}
