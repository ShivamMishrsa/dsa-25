import java.util.Scanner;

class Node {
    int data;
    Node next;
}

class SinglyList {
    Node head = null;

    void insertAtStart(int data) {
        Node n = new Node();
        n.data = data;
        n.next = head;
        head = n;
    }

    void insertAtEnd(int data) {
        Node n = new Node();
        n.data = data;

        if (head == null) {
            head = n;
            return;
        }

        Node temp = head;
        while (temp.next != null) temp = temp.next;
        temp.next = n;
    }

    void insertAtPos(int data, int pos) {
        Node n = new Node();
        n.data = data;

        if (pos == 1) {
            n.next = head;
            head = n;
            return;
        }

        Node temp = head;
        for (int i = 1; i < pos - 1; i++) temp = temp.next;

        n.next = temp.next;
        temp.next = n;
    }

    void deleteStart() {
        if (head != null) head = head.next;
    }

    void deleteEnd() {
        if (head == null || head.next == null) {
            head = null;
            return;
        }

        Node temp = head;
        while (temp.next.next != null) temp = temp.next;
        temp.next = null;
    }

    void deletePos(int pos) {
        if (pos == 1) {
            head = head.next;
            return;
        }

        Node temp = head;
        for (int i = 1; i < pos - 1; i++) temp = temp.next;

        temp.next = temp.next.next;
    }

    void display() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        }
        System.out.println("NULL");
    }
}

public class MenuDrivenLL {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SinglyList list = new SinglyList();

        while (true) {
            System.out.println("\n1.Insert Start\n2.Insert End\n3.Insert Position\n4.Delete Start\n5.Delete End\n6.Delete Position\n7.Display\n8.Exit");
            int ch = sc.nextInt();

            if (ch == 1) {
                list.insertAtStart(sc.nextInt());
            } else if (ch == 2) {
                list.insertAtEnd(sc.nextInt());
            } else if (ch == 3) {
                list.insertAtPos(sc.nextInt(), sc.nextInt());
            } else if (ch == 4) {
                list.deleteStart();
            } else if (ch == 5) {
                list.deleteEnd();
            } else if (ch == 6) {
                list.deletePos(sc.nextInt());
            } else if (ch == 7) {
                list.display();
            } else break;
        }
    }
}
