import java.util.Scanner;

public class FactorialBoth {
    static long factIter(int n) {
        long res = 1;
        for (int i = 2; i <= n; i++) res *= i;
        return res;
    }
    static long factRec(int n) {
        if (n <= 1) return 1;
        return n * factRec(n - 1);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("n: ");
        int n = sc.nextInt();
        System.out.println("Iterative: " + factIter(n));
        System.out.println("Recursive: " + factRec(n));
        sc.close();
    }
}
