class DNode {
    int data;
    DNode prev, next;
}

class DoublyList {
    DNode head = null;

    void insert(int data) {
        DNode n = new DNode();
        n.data = data;

        if (head == null) {
            head = n;
            return;
        }
        DNode temp = head;
        while (temp.next != null) temp = temp.next;
        temp.next = n;
        n.prev = temp;
    }

    void display() {
        DNode temp = head;
        while (temp != null) {
            System.out.print(temp.data + " <-> ");
            temp = temp.next;
        }
        System.out.println("NULL");
    }
}

public class DLL {
    public static void main(String[] args) {
        DoublyList dl = new DoublyList();
        dl.insert(10);
        dl.insert(20);
        dl.insert(30);
        dl.display();
    }
}
