
class CircularQueue {
    int size = 5;
    int arr[] = new int[size];
    int front = -1, rear = -1;

    boolean isFull() {
        return ((rear + 1) % size == front);
    }

    boolean isEmpty() {
        return (front == -1);
    }

    void push(int x) {
        if (isFull()) {
            System.out.println("Queue Overflow");
            return;
        }

        if (front == -1) front = 0;
        rear = (rear + 1) % size;
        arr[rear] = x;
        System.out.println(x + " inserted");
    }

    void pop() {
        if (isEmpty()) {
            System.out.println("Queue Underflow");
            return;
        }

        System.out.println(arr[front] + " removed");

        if (front == rear) {
            front = rear = -1;
        } else {
            front = (front + 1) % size;
        }
    }

    void display() {
        if (isEmpty()) {
            System.out.println("Queue is empty");
            return;
        }

        System.out.print("Queue: ");
        int i = front;
        while (true) {
            System.out.print(arr[i] + " ");
            if (i == rear) break;
            i = (i + 1) % size;
        }
        System.out.println();
    }

        public static void main(String[] args) {
        CircularQueue q = new CircularQueue();

        q.push(10);
        q.push(20);
        q.push(30);
        q.display();

        q.pop();
        q.display();

        q.push(40);
        q.push(50);
        q.push(60); // this will overflow
        q.display();
    }
}

