class StackArray {
    int top = -1;
    int size = 5;
    int arr[] = new int[size];

    boolean isEmpty() {
        return (top == -1);
    }

    boolean isFull() {
        return (top == size - 1);
    }

    void push(int x) {
        if (!isFull()) arr[++top] = x;
        else System.out.println("Stack Overflow");
    }

    void pop() {
        if (!isEmpty()) top--;
        else System.out.println("Stack Underflow");
    }
}

public class StackMain {
    public static void main(String args[]) {
        StackArray s = new StackArray();
        s.push(10);
        s.push(20);
        s.pop();
    }
}
