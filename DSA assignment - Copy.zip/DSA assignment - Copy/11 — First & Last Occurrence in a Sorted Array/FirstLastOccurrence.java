import java.util.*;

public class FirstLastOccurrence {

    static int first(int[] a, int x) {
        int l = 0, r = a.length - 1, ans = -1;
        while (l <= r) {
            int mid = (l + r) / 2;
            if (a[mid] == x) {
                ans = mid;
                r = mid - 1;   // move left for first
            } else if (a[mid] < x) l = mid + 1;
            else r = mid - 1;
        }
        return ans;
    }

    static int last(int[] a, int x) {
        int l = 0, r = a.length - 1, ans = -1;
        while (l <= r) {
            int mid = (l + r) / 2;
            if (a[mid] == x) {
                ans = mid;
                l = mid + 1;   // move right for last
            } else if (a[mid] < x) l = mid + 1;
            else r = mid - 1;
        }
        return ans;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("n: ");
        int n = sc.nextInt();

        int[] a = new int[n];
        for (int i = 0; i < n; i++) a[i] = sc.nextInt();
        Arrays.sort(a);
        System.out.println("Sorted: " + Arrays.toString(a));

        System.out.print("Element x: ");
        int x = sc.nextInt();

        System.out.println("First occurrence = " + first(a, x));
        System.out.println("Last occurrence = " + last(a, x));
    }
}
