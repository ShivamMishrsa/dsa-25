class BST {
    class Node {
        int key;
        Node left, right;
        Node(int key) { this.key = key; }
    }

    Node root;

    Node insert(Node root, int key) {
        if (root == null) return new Node(key);
        if (key < root.key) root.left = insert(root.left, key);
        else if (key > root.key) root.right = insert(root.right, key);
        return root;
    }

    Node search(Node root, int key) {
        if (root == null || root.key == key) return root;
        if (key < root.key) return search(root.left, key);
        return search(root.right, key);
    }

    Node delete(Node root, int key) {
        if (root == null) return null;

        if (key < root.key)
            root.left = delete(root.left, key);
        else if (key > root.key)
            root.right = delete(root.right, key);
        else {

            if (root.left == null) return root.right;
            else if (root.right == null) return root.left;

            Node temp = minValue(root.right);
            root.key = temp.key;
            root.right = delete(root.right, temp.key);
        }
        return root;
    }

    Node minValue(Node root) {
        while (root.left != null) root = root.left;
        return root;
    }

    void inorder(Node root) {
        if (root == null) return;
        inorder(root.left);
        System.out.print(root.key + " ");
        inorder(root.right);
    }

    public static void main(String[] args) {
        BST t = new BST();
        t.root = t.insert(t.root, 50);
        t.insert(t.root, 30);
        t.insert(t.root, 20);
        t.insert(t.root, 40);
        t.insert(t.root, 70);
        t.insert(t.root, 60);
        t.insert(t.root, 80);

        System.out.print("Inorder: ");
        t.inorder(t.root);
        System.out.println();

        System.out.println("Deleting 20...");
        t.root = t.delete(t.root, 20);
        t.inorder(t.root);
        System.out.println();

        System.out.println("Searching 60...");
        System.out.println(t.search(t.root, 60) != null ? "Found" : "Not Found");
    }
}
