import java.util.*;

class DFSGraph {
    private int V;
    private LinkedList<Integer> adj[];

    DFSGraph(int V) {
        this.V = V;
        adj = new LinkedList[V];
        for (int i = 0; i < V; i++)
            adj[i] = new LinkedList<>();
    }

    void addEdge(int v, int w) {
        adj[v].add(w);
    }

    void DFSUtil(int v, boolean visited[]) {
        visited[v] = true;
        System.out.print(v + " ");

        for (int x : adj[v]) {
            if (!visited[x])
                DFSUtil(x, visited);
        }
    }

    void DFS(int start) {
        boolean visited[] = new boolean[V];
        DFSUtil(start, visited);
    }

    public static void main(String[] args) {
        DFSGraph g = new DFSGraph(5);
        g.addEdge(0, 1);
        g.addEdge(0, 2);
        g.addEdge(1, 3);
        g.addEdge(2, 4);

        System.out.print("DFS: ");
        g.DFS(0);
    }
}
