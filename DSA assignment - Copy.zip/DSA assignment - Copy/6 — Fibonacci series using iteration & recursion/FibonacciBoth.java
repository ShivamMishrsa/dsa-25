import java.util.Scanner;

public class FibonacciBoth {

    // Recursive method
    static int fibRec(int n) {
        if (n <= 1) return n;
        return fibRec(n - 1) + fibRec(n - 2);
    }

    // Iterative method
    static void fibIter(int n) {
        int a = 0, b = 1;
        System.out.print("Iterative: ");
        if (n >= 1) System.out.print(a + " ");
        if (n >= 2) System.out.print(b + " ");

        for (int i = 3; i <= n; i++) {
            int c = a + b;
            System.out.print(c + " ");
            a = b;
            b = c;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("n: ");
        int n = sc.nextInt();

        // Iterative
        fibIter(n);

        // Recursive
        System.out.print("Recursive: ");
        for (int i = 0; i < n; i++)
            System.out.print(fibRec(i) + " ");
    }
}
