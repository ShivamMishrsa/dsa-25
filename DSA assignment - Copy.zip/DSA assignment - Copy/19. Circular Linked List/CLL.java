class CNode {
    int data;
    CNode next;
}

class CircularList {
    CNode head = null;

    void insert(int data) {
        CNode n = new CNode();
        n.data = data;

        if (head == null) {
            head = n;
            n.next = head;
            return;
        }

        CNode temp = head;
        while (temp.next != head) temp = temp.next;

        temp.next = n;
        n.next = head;
    }

    void display() {
        if (head == null) return;

        CNode temp = head;
        do {
            System.out.print(temp.data + " -> ");
            temp = temp.next;
        } while (temp != head);

        System.out.println("(back to head)");
    }
}

public class CLL {
    public static void main(String[] args) {
        CircularList cl = new CircularList();
        cl.insert(10);
        cl.insert(20);
        cl.insert(30);
        cl.display();
    }
}
