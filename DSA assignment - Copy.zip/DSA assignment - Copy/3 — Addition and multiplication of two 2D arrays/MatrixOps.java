import java.util.Scanner;

public class MatrixOps {

    static int[][] readMatrix(Scanner sc, int r, int c) {
        int[][] m = new int[r][c];
        for (int i = 0; i < r; i++)
            for (int j = 0; j < c; j++)
                m[i][j] = sc.nextInt();
        return m;
    }

    static void print(int[][] m) {
        for (int[] row : m) {
            for (int x : row)
                System.out.print(x + " ");
            System.out.println();
        }
    }

    static int[][] add(int[][] A, int[][] B) {
        int r = A.length, c = A[0].length;
        int[][] C = new int[r][c];
        for (int i = 0; i < r; i++)
            for (int j = 0; j < c; j++)
                C[i][j] = A[i][j] + B[i][j];
        return C;
    }

    static int[][] mul(int[][] A, int[][] B) {
        int r = A.length, m = A[0].length, c = B[0].length;
        int[][] C = new int[r][c];
        for (int i = 0; i < r; i++)
            for (int j = 0; j < c; j++) {
                int sum = 0;
                for (int k = 0; k < m; k++)
                    sum += A[i][k] * B[k][j];
                C[i][j] = sum;
            }
        return C;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Rows and cols of A: ");
        int r = sc.nextInt(), c = sc.nextInt();

        System.out.println("Enter A:");
        int[][] A = readMatrix(sc, r, c);

        System.out.println("Enter B (for addition same size; for multiplication columns of A must equal rows of B)");
        System.out.print("Rows and cols of B: ");
        int r2 = sc.nextInt(), c2 = sc.nextInt();
        int[][] B = readMatrix(sc, r2, c2);

        if (r == r2 && c == c2) {
            System.out.println("\nA + B:");
            print(add(A, B));
        } else {
            System.out.println("\nAddition not possible (dimension mismatch)");
        }

        if (c == r2) {
            System.out.println("\nA * B:");
            print(mul(A, B));
        } else {
            System.out.println("\nMultiplication not possible (dimension mismatch)");
        }

        sc.close();
    }
}
